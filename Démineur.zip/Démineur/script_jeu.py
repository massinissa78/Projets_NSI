import pygame
import random
import json
import os

if os.path.exists("options.txt"):
    with open("options.txt", "r") as f:
        data_options = json.load(f)
    options_nbr_mines = data_options["nbr_mines"]
    options_mode_chrono = data_options["mode_chrono"]
    options_sur_autour = data_options["sur_autour"]
    options_limite_temps = data_options["limite_temps"]
else:  
    data_options = {
        "nbr_mines": 60,
        "mode_chrono": False,
        "sur_autour": True,
        "limite_temps": 240
    }
    with open("options.txt", "w") as f:
        json.dump(data_options, f)
    options_nbr_mines = 60
    options_mode_chrono = False
    options_sur_autour = True
    options_limite_temps = 240

def autour_coord(x_scan,y_scan,x_clic,y_clic):
    return (x_scan == x_clic and y_scan == y_clic) or (x_scan == x_clic+1 and y_scan == y_clic) or (x_scan == x_clic-1 and y_scan == y_clic) or (x_scan == x_clic and y_scan == y_clic+1) or (x_scan == x_clic and y_scan == y_clic-1) or (x_scan == x_clic+1 and y_scan == y_clic+1) or (x_scan == x_clic+1 and y_scan == y_clic-1) or (x_scan == x_clic-1 and y_scan == y_clic+1) or (x_scan == x_clic-1 and y_scan == y_clic-1)
    
def cases_adjacentes(g):
    
    for ligne in range(len(g.cases)):
        for colonne in range(len(g.cases[ligne])):
            if not g.cases[ligne][colonne] == "M":

                if 0<ligne<len(g.cases)-1 and 0<colonne<len(g.cases[ligne])-1:
                    
                    if g.cases[ligne][colonne-1] == "M":
                        g.cases[ligne][colonne] += 1
                    if g.cases[ligne][colonne+1] == "M":
                        g.cases[ligne][colonne] += 1
                    if g.cases[ligne-1][colonne-1] == "M":
                        g.cases[ligne][colonne] += 1
                    if g.cases[ligne-1][colonne] == "M":
                        g.cases[ligne][colonne] += 1
                    if g.cases[ligne-1][colonne+1] == "M":
                        g.cases[ligne][colonne] += 1
                    if g.cases[ligne+1][colonne-1] == "M":
                        g.cases[ligne][colonne] += 1
                    if g.cases[ligne+1][colonne] == "M":
                        g.cases[ligne][colonne] += 1
                    if g.cases[ligne+1][colonne+1] == "M":
                        g.cases[ligne][colonne] += 1

                elif ligne == 0 and 0<colonne<len(g.cases[ligne])-1:
                    
                    if g.cases[ligne][colonne-1] == "M":
                        g.cases[ligne][colonne] += 1
                    if g.cases[ligne][colonne+1] == "M":
                        g.cases[ligne][colonne] += 1
                    if g.cases[ligne+1][colonne-1] == "M":
                        g.cases[ligne][colonne] += 1
                    if g.cases[ligne+1][colonne] == "M":
                        g.cases[ligne][colonne] += 1
                    if g.cases[ligne+1][colonne+1] == "M":
                        g.cases[ligne][colonne] += 1
                        
                elif 0<ligne<len(g.cases)-1 and colonne == 0:
                    
                    if g.cases[ligne][colonne+1] == "M":
                        g.cases[ligne][colonne] += 1
                    if g.cases[ligne-1][colonne] == "M":
                        g.cases[ligne][colonne] += 1
                    if g.cases[ligne-1][colonne+1] == "M":
                        g.cases[ligne][colonne] += 1
                    if g.cases[ligne+1][colonne] == "M":
                        g.cases[ligne][colonne] += 1
                    if g.cases[ligne+1][colonne+1] == "M":
                        g.cases[ligne][colonne] += 1

                elif ligne == len(g.cases)-1 and 0<colonne<len(g.cases[ligne])-1:
                    
                    if g.cases[ligne][colonne-1] == "M":
                        g.cases[ligne][colonne] += 1
                    if g.cases[ligne][colonne+1] == "M":
                        g.cases[ligne][colonne] += 1
                    if g.cases[ligne-1][colonne-1] == "M":
                        g.cases[ligne][colonne] += 1
                    if g.cases[ligne-1][colonne] == "M":
                        g.cases[ligne][colonne] += 1
                    if g.cases[ligne-1][colonne+1] == "M":
                        g.cases[ligne][colonne] += 1

                elif 0<ligne<len(g.cases)-1 and colonne == len(g.cases[ligne])-1:
                    
                    if g.cases[ligne][colonne-1] == "M":
                        g.cases[ligne][colonne] += 1
                    if g.cases[ligne-1][colonne-1] == "M":
                        g.cases[ligne][colonne] += 1
                    if g.cases[ligne-1][colonne] == "M":
                        g.cases[ligne][colonne] += 1
                    if g.cases[ligne+1][colonne-1] == "M":
                        g.cases[ligne][colonne] += 1
                    if g.cases[ligne+1][colonne] == "M":
                        g.cases[ligne][colonne] += 1
                        
                elif ligne == len(g.cases)-1 and colonne == len(g.cases[ligne])-1:
                    
                    if g.cases[ligne][colonne-1] == "M":
                        g.cases[ligne][colonne] += 1
                    if g.cases[ligne-1][colonne-1] == "M":
                        g.cases[ligne][colonne] += 1
                    if g.cases[ligne-1][colonne] == "M":
                        g.cases[ligne][colonne] += 1

                elif ligne == len(g.cases)-1 and colonne == 0:
                    
                    if g.cases[ligne][colonne+1] == "M":
                        g.cases[ligne][colonne] += 1
                    if g.cases[ligne-1][colonne] == "M":
                        g.cases[ligne][colonne] += 1
                    if g.cases[ligne-1][colonne+1] == "M":
                        g.cases[ligne][colonne] += 1

                elif ligne == 0 and colonne == len(g.cases[ligne])-1:
                    
                    if g.cases[ligne][colonne-1] == "M":
                        g.cases[ligne][colonne] += 1
                    if g.cases[ligne+1][colonne-1] == "M":
                        g.cases[ligne][colonne] += 1
                    if g.cases[ligne+1][colonne] == "M":
                        g.cases[ligne][colonne] += 1

                elif ligne == 0 and colonne == 0:
                    
                    if g.cases[ligne][colonne+1] == "M":
                        g.cases[ligne][colonne] += 1
                    if g.cases[ligne+1][colonne] == "M":
                        g.cases[ligne][colonne] += 1
                    if g.cases[ligne+1][colonne+1] == "M":
                        g.cases[ligne][colonne] += 1

    return g

class Grille :
    
    def __init__(self,taille_case,cases_long,cases_haut,nbr_mines):
        self.nbr_mines = nbr_mines
        self.est_prete = False
        self.taille_case = taille_case
        self.cases_long = cases_long
        self.cases_haut = cases_haut
        self.cases = []
        self.cases_clic = []
        self.cases_drapeau = []
        self.adjacentes_decouvertes = []
        
    def creation(self):
        L = []
        l = []
        ll = []
        lll = []
        for i in range(self.cases_haut):
            L2 = []
            for j in range(self.cases_long):
                L2.append(0)
            L.append(L2)
        self.cases = L
        for i in range(self.cases_haut):
            l2 = []
            for j in range(self.cases_long):
                l2.append(False)
            l.append(l2)
        self.cases_clic = l
        for i in range(self.cases_haut):
            ll2 = []
            for j in range(self.cases_long):
                ll2.append(False)
            ll.append(ll2)
        self.cases_drapeau = ll
        for i in range(self.cases_haut):
            lll2 = []
            for j in range(self.cases_long):
                lll2.append(0)
            lll.append(lll2)
        self.adjacentes_decouvertes = lll
        
    
    def placer_mines(self,case_x,case_y,s_autour):
        plage = [i for i in range(self.cases_long)]
        for i in range(self.nbr_mines):
            ligne = random.choice(plage)
            colonne = random.choice(plage)
            if s_autour:
                while autour_coord(colonne,ligne,case_x,case_y) or self.cases[ligne][colonne] == "M":
                    ligne = random.choice(plage)
                    colonne = random.choice(plage)
            else :
                while (colonne == case_x and ligne == case_y) or self.cases[ligne][colonne] == "M":
                    ligne = random.choice(plage)
                    colonne = random.choice(plage)
            if self.cases[ligne][colonne] == 0:
                self.cases[ligne][colonne] = "M"
    
    def calibrage(self):
        cases_adjacentes(self)
        for i in range(len(self.cases)):
            for j in range(len(self.cases[i])):
                if self.cases[i][j] == 0:
                    self.adjacentes_decouvertes[i][j] = 1
                else:
                    self.adjacentes_decouvertes[i][j] = 0
        self.est_prete = True
        
    def reinitialiser(self):
        self.creation()
        #self.placer_mines()
        #self.calibrage()
        self.est_prete = False
        
class FenetreJeu:
    """
    Classe qui gère la fenêtre principale du jeu.
    """
    def __init__(self, largeur, hauteur, titre, grille):
        self.grille = grille
        self.largeur = largeur
        self.hauteur = hauteur
        self.titre = titre
        self.en_cours = True  # Variable pour savoir si le jeu tourne

        # Initialisation de pygame et création de la fenêtre
        pygame.init()
        self.fenetre = pygame.display.set_mode((self.largeur, self.hauteur))
        pygame.display.set_caption(self.titre)
        
        # Couleurs
        # self.couleur_fond = (48, 89, 112)  # Bleu foncé
        self.couleur_fond = (47, 105, 110)
        self.couleur_case = (149, 211, 219) # Bleu clair
        self.couleur_case_cliquee = (255, 255, 255) # Blanc
        self.couleur_drapeau = (255, 0, 0) # Rouge
        self.couleur_texte = (0, 0, 0) # Noir

        # Boutons cliquables
        self.bouton_largeur = 200
        self.bouton_hauteur = 50
        self.bouton_jouer = pygame.Rect(100, self.hauteur // 2 + 30, self.bouton_largeur, self.bouton_hauteur)
        self.bouton_jouer_held = False
        self.bouton_charger = pygame.Rect(400, self.hauteur // 2 + 30, self.bouton_largeur, self.bouton_hauteur)
        self.bouton_charger_held = False
        self.bouton_options = pygame.Rect(self.largeur // 2 - self.bouton_largeur // 2, self.hauteur // 2 + 140 + self.bouton_hauteur, self.bouton_largeur, self.bouton_hauteur)
        self.bouton_options_held = False
        self.bouton_valider = pygame.Rect(self.largeur // 2 - self.bouton_largeur // 2, self.hauteur // 2 + 140 + self.bouton_hauteur, self.bouton_largeur, self.bouton_hauteur)
        self.bouton_valider_held = False
        self.bouton_diff = pygame.Rect(0.6 * self.largeur, self.hauteur * 0.4, self.bouton_largeur * 0.7, self.bouton_hauteur * 0.7)
        self.bouton_mode_chrono = pygame.Rect(0.6 * self.largeur, self.hauteur * 0.4 + 20 + self.bouton_hauteur * 0.7, self.bouton_largeur * 0.7, self.bouton_hauteur * 0.7)
        self.box_input_nbr_mines = pygame.Rect(0.6 * self.largeur, self.hauteur * 0.4 + 3 * (20 + self.bouton_hauteur * 0.7), self.bouton_largeur * 0.7, self.bouton_hauteur * 0.7)
        self.box_input_limite_temps = pygame.Rect(0.6 * self.largeur, self.hauteur * 0.4 + 2 * (20 + self.bouton_hauteur * 0.7), self.bouton_largeur * 0.7, self.bouton_hauteur * 0.7)
        self.bouton_sauver = pygame.Rect(490, 20, self.bouton_largeur, self.bouton_hauteur)
        self.bouton_sauver_held = False
        self.bouton_rejouer = pygame.Rect(100, self.hauteur // 2 + 50, self.bouton_largeur, self.bouton_hauteur)
        self.bouton_rejouer_held = False
        self.bouton_quitter = pygame.Rect(400, self.hauteur // 2 + 50, self.bouton_largeur, self.bouton_hauteur)
        self.bouton_quitter_held = False
        
        # Marges et espacement
        self.marge_gauche = 35
        self.marge_haut = 25
        self.espacement_cases = 6

        # Variables pour le jeu principal
        self.input_nbr_mines = grille.nbr_mines
        self.input_nbr_mines_active = False
        self.sur_autour = options_sur_autour
        self.mode_chrono = options_mode_chrono
        self.limite_temps = options_limite_temps
        self.input_limite_temps = self.limite_temps
        self.input_limite_temps_active = False
        self.debut_timer = 0
        self.ingame_timer = 0
        self.delai_timer = 0
        self.cases = {}
        self.jeu_commence = False
        self.options = False
        self.nbr_drapeaux = grille.nbr_mines
        self.nbr_cases_clic = 0
        self.fin_jeu = False
        self.last_frame = False
        self.perdu = False
        self.gagne = False
        self.rejouer = 0

    def lancer_jeu(self):
        """
        Boucle principale du jeu.
        """
        self.musique()
        self.debut_timer = pygame.time.get_ticks()
        while self.en_cours:
            self.boucle_jeu()     # Mise à jour les variables
            self.dessiner()          # Rendu graphique
            pygame.display.flip()   # Mise à jour de l'écran
        pygame.quit()
        
    def musique(self):
        """
        Lance aléatoirement une musique parmi 4 disponibles. (AJOUTER UN DOSSIER "musiques")
        """
        #m = random.randint(1,4)
        #pygame.mixer.music.load(str('musiques/musique'+str(m)+'.mp3'))
        #pygame.mixer.music.set_volume(0.2)
        #pygame.mixer.music.play(-1)
        
    def cases_adjacentes(self,grille,ligne,colonne):
        """
        Dévoile les cases adjacentes lorsque le joueur clique sur une case proche d'aucune mine.
        """
        if 0<ligne<len(grille.cases)-1 and 0<colonne<len(grille.cases[ligne])-1:
            
            if grille.cases[ligne][colonne-1] != "M" and not grille.cases_drapeau[ligne][colonne-1]:
                if not grille.cases_clic[ligne][colonne-1]:
                    grille.cases_clic[ligne][colonne-1] = True
                    self.nbr_cases_clic += 1
            if grille.cases[ligne][colonne+1] != "M" and not grille.cases_drapeau[ligne][colonne+1]:
                if not grille.cases_clic[ligne][colonne+1]:
                    grille.cases_clic[ligne][colonne+1] = True
                    self.nbr_cases_clic += 1
            if grille.cases[ligne-1][colonne-1] != "M" and not grille.cases_drapeau[ligne-1][colonne-1]:
                if not grille.cases_clic[ligne-1][colonne-1]:
                    grille.cases_clic[ligne-1][colonne-1] = True
                    self.nbr_cases_clic += 1
            if grille.cases[ligne-1][colonne] != "M" and not grille.cases_drapeau[ligne-1][colonne]:
                if not grille.cases_clic[ligne-1][colonne]:
                    grille.cases_clic[ligne-1][colonne] = True
                    self.nbr_cases_clic += 1
            if grille.cases[ligne-1][colonne+1] != "M" and not grille.cases_drapeau[ligne-1][colonne+1]:
                if not grille.cases_clic[ligne-1][colonne+1]:
                    grille.cases_clic[ligne-1][colonne+1] = True
                    self.nbr_cases_clic += 1
            if grille.cases[ligne+1][colonne-1] != "M" and not grille.cases_drapeau[ligne+1][colonne-1]:
                if not grille.cases_clic[ligne+1][colonne-1]:
                    grille.cases_clic[ligne+1][colonne-1] = True
                    self.nbr_cases_clic += 1
            if grille.cases[ligne+1][colonne] != "M" and not grille.cases_drapeau[ligne+1][colonne]:
                if not grille.cases_clic[ligne+1][colonne]:
                    grille.cases_clic[ligne+1][colonne] = True
                    self.nbr_cases_clic += 1
            if grille.cases[ligne+1][colonne+1] != "M" and not grille.cases_drapeau[ligne+1][colonne+1]:
                if not grille.cases_clic[ligne+1][colonne+1]:
                    grille.cases_clic[ligne+1][colonne+1] = True
                    self.nbr_cases_clic += 1

        elif ligne == 0 and 0<colonne<len(grille.cases[ligne])-1:
            
            if grille.cases[ligne][colonne-1] != "M" and not grille.cases_drapeau[ligne][colonne-1]:
                if not grille.cases_clic[ligne][colonne-1]:
                    grille.cases_clic[ligne][colonne-1] = True
                    self.nbr_cases_clic += 1
            if grille.cases[ligne][colonne+1] != "M" and not grille.cases_drapeau[ligne][colonne+1]:
                if not grille.cases_clic[ligne][colonne+1]:
                    grille.cases_clic[ligne][colonne+1] = True
                    self.nbr_cases_clic += 1
            if grille.cases[ligne+1][colonne-1] != "M" and not grille.cases_drapeau[ligne+1][colonne-1]:
                if not grille.cases_clic[ligne+1][colonne-1]:
                    grille.cases_clic[ligne+1][colonne-1] = True
                    self.nbr_cases_clic += 1
            if grille.cases[ligne+1][colonne] != "M" and not grille.cases_drapeau[ligne+1][colonne]:
                if not grille.cases_clic[ligne+1][colonne]:
                    grille.cases_clic[ligne+1][colonne] = True
                    self.nbr_cases_clic += 1
            if grille.cases[ligne+1][colonne+1] != "M" and not grille.cases_drapeau[ligne+1][colonne+1]:
                if not grille.cases_clic[ligne+1][colonne+1]:
                    grille.cases_clic[ligne+1][colonne+1] = True
                    self.nbr_cases_clic += 1
                
        elif 0<ligne<len(grille.cases)-1 and colonne == 0:
            
            if grille.cases[ligne][colonne+1] != "M" and not grille.cases_drapeau[ligne][colonne+1]:
                if not grille.cases_clic[ligne][colonne+1]:
                    grille.cases_clic[ligne][colonne+1] = True
                    self.nbr_cases_clic += 1
            if grille.cases[ligne-1][colonne] != "M" and not grille.cases_drapeau[ligne-1][colonne]:
                if not grille.cases_clic[ligne-1][colonne]:
                    grille.cases_clic[ligne-1][colonne] = True
                    self.nbr_cases_clic += 1
            if grille.cases[ligne-1][colonne+1] != "M" and not grille.cases_drapeau[ligne-1][colonne+1]:
                if not grille.cases_clic[ligne-1][colonne+1]:
                    grille.cases_clic[ligne-1][colonne+1] = True
                    self.nbr_cases_clic += 1
            if grille.cases[ligne+1][colonne] != "M" and not grille.cases_drapeau[ligne+1][colonne]:
                if not grille.cases_clic[ligne+1][colonne]:
                    grille.cases_clic[ligne+1][colonne] = True
                    self.nbr_cases_clic += 1
            if grille.cases[ligne+1][colonne+1] != "M" and not grille.cases_drapeau[ligne+1][colonne+1]:
                if not grille.cases_clic[ligne+1][colonne+1]:
                    grille.cases_clic[ligne+1][colonne+1] = True
                    self.nbr_cases_clic += 1

        elif ligne == len(grille.cases)-1 and 0<colonne<len(grille.cases[ligne])-1:
            
            if grille.cases[ligne][colonne-1] != "M" and not grille.cases_drapeau[ligne][colonne-1]:
                if not grille.cases_clic[ligne][colonne-1]:
                    grille.cases_clic[ligne][colonne-1] = True
                    self.nbr_cases_clic += 1
            if grille.cases[ligne][colonne+1] != "M" and not grille.cases_drapeau[ligne][colonne+1]:
                if not grille.cases_clic[ligne][colonne+1]:
                    grille.cases_clic[ligne][colonne+1] = True
                    self.nbr_cases_clic += 1
            if grille.cases[ligne-1][colonne-1] != "M" and not grille.cases_drapeau[ligne-1][colonne-1]:
                if not grille.cases_clic[ligne-1][colonne-1]:
                    grille.cases_clic[ligne-1][colonne-1] = True
                    self.nbr_cases_clic += 1
            if grille.cases[ligne-1][colonne] != "M" and not grille.cases_drapeau[ligne-1][colonne]:
                if not grille.cases_clic[ligne-1][colonne]:
                    grille.cases_clic[ligne-1][colonne] = True
                    self.nbr_cases_clic += 1
            if grille.cases[ligne-1][colonne+1] != "M" and not grille.cases_drapeau[ligne-1][colonne+1]:
                if not grille.cases_clic[ligne-1][colonne+1]:
                    grille.cases_clic[ligne-1][colonne+1] = True
                    self.nbr_cases_clic += 1

        elif 0<ligne<len(grille.cases)-1 and colonne == len(grille.cases[ligne])-1:
            
            if grille.cases[ligne][colonne-1] != "M" and not grille.cases_drapeau[ligne][colonne-1]:
                if not grille.cases_clic[ligne][colonne-1]:
                    grille.cases_clic[ligne][colonne-1] = True
                    self.nbr_cases_clic += 1
            if grille.cases[ligne-1][colonne-1] != "M" and not grille.cases_drapeau[ligne-1][colonne-1]:
                if not grille.cases_clic[ligne-1][colonne-1]:
                    grille.cases_clic[ligne-1][colonne-1] = True
                    self.nbr_cases_clic += 1
            if grille.cases[ligne-1][colonne] != "M" and not grille.cases_drapeau[ligne-1][colonne]:
                if not grille.cases_clic[ligne-1][colonne]:
                    grille.cases_clic[ligne-1][colonne] = True
                    self.nbr_cases_clic += 1
            if grille.cases[ligne+1][colonne-1] != "M" and not grille.cases_drapeau[ligne+1][colonne-1]:
                if not grille.cases_clic[ligne+1][colonne-1]:
                    grille.cases_clic[ligne+1][colonne-1] = True
                    self.nbr_cases_clic += 1
            if grille.cases[ligne+1][colonne] != "M" and not grille.cases_drapeau[ligne+1][colonne]:
                if not grille.cases_clic[ligne+1][colonne]:
                    grille.cases_clic[ligne+1][colonne] = True
                    self.nbr_cases_clic += 1
                
        elif ligne == len(grille.cases)-1 and colonne == len(grille.cases[ligne])-1:
            
            if grille.cases[ligne][colonne-1] != "M" and not grille.cases_drapeau[ligne][colonne-1]:
                if not grille.cases_clic[ligne][colonne-1]:
                    grille.cases_clic[ligne][colonne-1] = True
                    self.nbr_cases_clic += 1
            if grille.cases[ligne-1][colonne-1] != "M" and not grille.cases_drapeau[ligne-1][colonne-1]:
                if not grille.cases_clic[ligne-1][colonne-1]:
                    grille.cases_clic[ligne-1][colonne-1] = True
                    self.nbr_cases_clic += 1
            if grille.cases[ligne-1][colonne] != "M" and not grille.cases_drapeau[ligne-1][colonne]:
                if not grille.cases_clic[ligne-1][colonne]:
                    grille.cases_clic[ligne-1][colonne] = True
                    self.nbr_cases_clic += 1

        elif ligne == len(grille.cases)-1 and colonne == 0:
            
            if grille.cases[ligne][colonne+1] != "M" and not grille.cases_drapeau[ligne][colonne+1]:
                if not grille.cases_clic[ligne][colonne+1]:
                    grille.cases_clic[ligne][colonne+1] = True
                    self.nbr_cases_clic += 1
            if grille.cases[ligne-1][colonne] != "M" and not grille.cases_drapeau[ligne-1][colonne]:
                if not grille.cases_clic[ligne-1][colonne]:
                    grille.cases_clic[ligne-1][colonne] = True
                    self.nbr_cases_clic += 1
            if grille.cases[ligne-1][colonne+1] != "M" and not grille.cases_drapeau[ligne-1][colonne+1]:
                if not grille.cases_clic[ligne-1][colonne+1]:
                    grille.cases_clic[ligne-1][colonne+1] = True
                    self.nbr_cases_clic += 1

        elif ligne == 0 and colonne == len(grille.cases[ligne])-1:
            
            if grille.cases[ligne][colonne-1] != "M" and not grille.cases_drapeau[ligne][colonne-1]:
                if not grille.cases_clic[ligne][colonne-1]:
                    grille.cases_clic[ligne][colonne-1] = True
                    self.nbr_cases_clic += 1
            if grille.cases[ligne+1][colonne-1] != "M" and not grille.cases_drapeau[ligne+1][colonne-1]:
                if not grille.cases_clic[ligne+1][colonne-1]:
                    grille.cases_clic[ligne+1][colonne-1] = True
                    self.nbr_cases_clic += 1
            if grille.cases[ligne+1][colonne] != "M" and not grille.cases_drapeau[ligne+1][colonne]:
                if not grille.cases_clic[ligne+1][colonne]:
                    grille.cases_clic[ligne+1][colonne] = True
                    self.nbr_cases_clic += 1

        elif ligne == 0 and colonne == 0:
            
            if grille.cases[ligne][colonne+1] != "M" and not grille.cases_drapeau[ligne][colonne+1]:
                if not grille.cases_clic[ligne][colonne+1]:
                    grille.cases_clic[ligne][colonne+1] = True
                    self.nbr_cases_clic += 1
            if grille.cases[ligne+1][colonne] != "M" and not grille.cases_drapeau[ligne+1][colonne]:
                if not grille.cases_clic[ligne+1][colonne]:
                    grille.cases_clic[ligne+1][colonne] = True
                    self.nbr_cases_clic += 1
            if grille.cases[ligne+1][colonne+1] != "M" and not grille.cases_drapeau[ligne+1][colonne+1]:
                if not grille.cases_clic[ligne+1][colonne+1]:
                    grille.cases_clic[ligne+1][colonne+1] = True
                    self.nbr_cases_clic += 1
                    
        grille.adjacentes_decouvertes[ligne][colonne] = 2
        
        for i in range(len(grille.cases_clic)):
            for j in range(len(grille.cases_clic[i])):
                if grille.cases_clic[i][j] == True and grille.cases[i][j] == 0 and grille.adjacentes_decouvertes[i][j] == 1:
                    self.cases_adjacentes(grille,i,j)

    def boucle_jeu(self):
        """
        Boucle de jeu
        """
        if not self.fin_jeu: # Tant que le joueur est en jeu
            
            if self.jeu_commence:
                if self.grille.est_prete:
                    self.ingame_timer = ((pygame.time.get_ticks() - self.debut_timer) // 1000) + self.delai_timer
                    if self.ingame_timer >= 999:
                        self.ingame_timer = 999
                    if self.mode_chrono:
                        if self.ingame_timer >= self.limite_temps:
                            for ligne in range(len(self.grille.cases)):
                                for colonne in range(len(self.grille.cases[ligne])):
                                    if self.grille.cases[ligne][colonne] == 'M':
                                        self.grille.cases_clic[ligne][colonne] = True
                            print("Vous Avez Perdu")
                            self.perdu = True
            
            for event in pygame.event.get(): # Attente des évènements
                
                if event.type == pygame.QUIT: # Si le jeu est quitté
                    self.en_cours = False
                    
                elif event.type == pygame.KEYDOWN and self.input_nbr_mines_active and not self.jeu_commence and self.options: # Si le joueur écrit dans la zone de texte "Nombre de Mines"
                    if event.key in [pygame.K_0,pygame.K_KP0]:
                        if len(str(self.input_nbr_mines)) >= 3:
                            self.input_nbr_mines = self.grille.cases_long * self.grille.cases_haut - 9
                        else :
                            self.input_nbr_mines = str(self.input_nbr_mines) + "0"
                            self.input_nbr_mines = int(self.input_nbr_mines)
                    elif event.key in [pygame.K_1,pygame.K_KP1]:
                        if len(str(self.input_nbr_mines)) >= 3:
                            self.input_nbr_mines = self.grille.cases_long * self.grille.cases_haut - 9
                        else :
                            self.input_nbr_mines = str(self.input_nbr_mines) + "1"
                            self.input_nbr_mines = int(self.input_nbr_mines)
                    elif event.key in [pygame.K_2,pygame.K_KP2]:
                        if len(str(self.input_nbr_mines)) >= 3:
                            self.input_nbr_mines = self.grille.cases_long * self.grille.cases_haut - 9
                        else :
                            self.input_nbr_mines = str(self.input_nbr_mines) + "2"
                            self.input_nbr_mines = int(self.input_nbr_mines)
                    elif event.key in [pygame.K_3,pygame.K_KP3]:
                        if len(str(self.input_nbr_mines)) >= 3:
                            self.input_nbr_mines = self.grille.cases_long * self.grille.cases_haut - 9
                        else :
                            self.input_nbr_mines = str(self.input_nbr_mines) + "3"
                            self.input_nbr_mines = int(self.input_nbr_mines)
                    elif event.key in [pygame.K_4,pygame.K_KP4]:
                        if len(str(self.input_nbr_mines)) >= 3:
                            self.input_nbr_mines = self.grille.cases_long * self.grille.cases_haut - 9
                        else :
                            self.input_nbr_mines = str(self.input_nbr_mines) + "4"
                            self.input_nbr_mines = int(self.input_nbr_mines)
                    elif event.key in [pygame.K_5,pygame.K_KP5]:
                        if len(str(self.input_nbr_mines)) >= 3:
                            self.input_nbr_mines = self.grille.cases_long * self.grille.cases_haut - 9
                        else :
                            self.input_nbr_mines = str(self.input_nbr_mines) + "5"
                            self.input_nbr_mines = int(self.input_nbr_mines)
                    elif event.key in [pygame.K_6,pygame.K_KP6]:
                        if len(str(self.input_nbr_mines)) >= 3:
                            self.input_nbr_mines = self.grille.cases_long * self.grille.cases_haut - 9
                        else :
                            self.input_nbr_mines = str(self.input_nbr_mines) + "6"
                            self.input_nbr_mines = int(self.input_nbr_mines)
                    elif event.key in [pygame.K_7,pygame.K_KP7]:
                        if len(str(self.input_nbr_mines)) >= 3:
                            self.input_nbr_mines = self.grille.cases_long * self.grille.cases_haut - 9
                        else :
                            self.input_nbr_mines = str(self.input_nbr_mines) + "7"
                            self.input_nbr_mines = int(self.input_nbr_mines)
                    elif event.key in [pygame.K_8,pygame.K_KP8]:
                        if len(str(self.input_nbr_mines)) >= 3:
                            self.input_nbr_mines = self.grille.cases_long * self.grille.cases_haut - 9
                        else :
                            self.input_nbr_mines = str(self.input_nbr_mines) + "8"
                            self.input_nbr_mines = int(self.input_nbr_mines)
                    elif event.key in [pygame.K_9,pygame.K_KP9]:
                        if len(str(self.input_nbr_mines)) >= 3:
                            self.input_nbr_mines = self.grille.cases_long * self.grille.cases_haut - 9
                        else :
                            self.input_nbr_mines = str(self.input_nbr_mines) + "9"
                            self.input_nbr_mines = int(self.input_nbr_mines)
                    elif event.key == pygame.K_BACKSPACE:
                        if len(str(self.input_nbr_mines)) > 1:
                            self.input_nbr_mines = str(self.input_nbr_mines)
                            self.input_nbr_mines = self.input_nbr_mines[:-1]
                            self.input_nbr_mines = int(self.input_nbr_mines)
                        else :
                            self.input_nbr_mines = ""
                    elif event.key == pygame.K_RETURN or event.key == pygame.K_ESCAPE:
                        if self.input_nbr_mines == "" or self.input_nbr_mines == 0:
                            self.input_nbr_mines = 1
                        elif self.input_nbr_mines >= self.grille.cases_long * self.grille.cases_haut:
                            self.input_nbr_mines = self.grille.cases_long * self.grille.cases_haut - 9
                        self.grille.nbr_mines = self.input_nbr_mines
                        self.nbr_drapeaux = self.grille.nbr_mines
                        print("Input Nombre Mines Inactif")
                        self.input_nbr_mines_active = False
                        
                elif event.type == pygame.KEYDOWN and self.input_limite_temps_active and not self.jeu_commence and self.options: # Si le joueur écrit dans la zone de texte "Limite de temps"
                    
                    if event.key in [pygame.K_0,pygame.K_KP0]:
                        if len(str(self.input_limite_temps)) >= 3:
                            self.input_limite_temps = 999
                        else :
                            self.input_limite_temps = str(self.input_limite_temps) + "0"
                            self.input_limite_temps = int(self.input_limite_temps)
                    elif event.key in [pygame.K_1,pygame.K_KP1]:
                        if len(str(self.input_limite_temps)) >= 3:
                            self.input_limite_temps = 999
                        else :
                            self.input_limite_temps = str(self.input_limite_temps) + "1"
                            self.input_limite_temps = int(self.input_limite_temps)
                    elif event.key in [pygame.K_2,pygame.K_KP2]:
                        if len(str(self.input_limite_temps)) >= 3:
                            self.input_limite_temps = 999
                        else :
                            self.input_limite_temps = str(self.input_limite_temps) + "2"
                            self.input_limite_temps = int(self.input_limite_temps)
                    elif event.key in [pygame.K_3,pygame.K_KP3]:
                        if len(str(self.input_limite_temps)) >= 3:
                            self.input_limite_temps = 999
                        else :
                            self.input_limite_temps = str(self.input_limite_temps) + "3"
                            self.input_limite_temps = int(self.input_limite_temps)
                    elif event.key in [pygame.K_4,pygame.K_KP4]:
                        if len(str(self.input_limite_temps)) >= 3:
                            self.input_limite_temps = 999
                        else :
                            self.input_limite_temps = str(self.input_limite_temps) + "4"
                            self.input_limite_temps = int(self.input_limite_temps)
                    elif event.key in [pygame.K_5,pygame.K_KP5]:
                        if len(str(self.input_limite_temps)) >= 3:
                            self.input_limite_temps = 999
                        else :
                            self.input_limite_temps = str(self.input_limite_temps) + "5"
                            self.input_limite_temps = int(self.input_limite_temps)
                    elif event.key in [pygame.K_6,pygame.K_KP6]:
                        if len(str(self.input_limite_temps)) >= 3:
                            self.input_limite_temps = 999
                        else :
                            self.input_limite_temps = str(self.input_limite_temps) + "6"
                            self.input_limite_temps = int(self.input_limite_temps)
                    elif event.key in [pygame.K_7,pygame.K_KP7]:
                        if len(str(self.input_limite_temps)) >= 3:
                            self.input_limite_temps = 999
                        else :
                            self.input_limite_temps = str(self.input_limite_temps) + "7"
                            self.input_limite_temps = int(self.input_limite_temps)
                    elif event.key in [pygame.K_8,pygame.K_KP8]:
                        if len(str(self.input_limite_temps)) >= 3:
                            self.input_limite_temps = 999
                        else :
                            self.input_limite_temps = str(self.input_limite_temps) + "8"
                            self.input_limite_temps = int(self.input_limite_temps)
                    elif event.key in [pygame.K_9,pygame.K_KP9]:
                        if len(str(self.input_limite_temps)) >= 3:
                            self.input_limite_temps = 999
                        else :
                            self.input_limite_temps = str(self.input_limite_temps) + "9"
                            self.input_limite_temps = int(self.input_limite_temps)
                    elif event.key == pygame.K_BACKSPACE:
                        if len(str(self.input_limite_temps)) > 1:
                            self.input_limite_temps = str(self.input_limite_temps)
                            self.input_limite_temps = self.input_limite_temps[:-1]
                            self.input_limite_temps = int(self.input_limite_temps)
                        else :
                            self.input_limite_temps = ""
                        
                    elif event.key == pygame.K_RETURN or event.key == pygame.K_ESCAPE:
                        if self.input_limite_temps == "" or self.input_limite_temps == 0:
                            self.input_limite_temps = 1
                        elif self.input_limite_temps >= 999:
                            self.input_limite_temps = 999
                        self.limite_temps = self.input_limite_temps
                        print("Input Limite Temps Inactif")
                        self.input_limite_temps_active = False
                       
                
                elif event.type == pygame.MOUSEBUTTONUP and event.button == 1: # Si le joueur fait un clic gauche (levé *pour éviter erreurs*)
                    
                    if self.bouton_jouer.collidepoint(event.pos) and not self.jeu_commence and not self.options: # Si le joueur clique sur "Jouer"
                        print("Nouvelle Partie Commencée")
                        self.jeu_commence = True
                        
                    elif self.bouton_options.collidepoint(event.pos) and not self.jeu_commence and not self.options: # Si le joueur clique sur "Options"
                        print("Menu Des Options")
                        self.options = True
                        
                    elif self.bouton_valider.collidepoint(event.pos) and not self.jeu_commence and self.options: # Si le joueur clique sur "Valider"
                        data_options["nbr_mines"] = self.grille.nbr_mines
                        data_options["mode_chrono"] = self.mode_chrono
                        data_options["sur_autour"] = self.sur_autour
                        data_options["limite_temps"] = self.limite_temps
                        with open("options.txt", "w") as f:
                            json.dump(data_options, f)
                        print("Menu Principal")
                        self.options = False
                        
                    elif self.bouton_diff.collidepoint(event.pos) and not self.jeu_commence and self.options: # Si le joueur change la difficulté
                        if self.sur_autour == True:
                            print("Mode Facile Désactivé")
                            self.sur_autour = False
                        else:
                            print("Mode Facile Activé")
                            self.sur_autour = True
                            
                    elif self.bouton_mode_chrono.collidepoint(event.pos) and not self.jeu_commence and self.options: # Si le joueur change la difficulté
                        if self.mode_chrono == True:
                            print("Mode Chrono Désactivé")
                            self.mode_chrono = False
                        else:
                            print("Mode Chrono Activé")
                            self.mode_chrono = True
                            
                    elif self.box_input_nbr_mines.collidepoint(event.pos) and not self.jeu_commence and self.options: # Si le joueur change le nombre de mines
                        if not self.input_nbr_mines_active:
                            print("Input Nombre Mines Actif")
                            self.input_nbr_mines_active = True
                            
                    elif self.box_input_limite_temps.collidepoint(event.pos) and not self.jeu_commence and self.options: # Si le joueur change la limite de temps
                        if not self.input_nbr_mines_active:
                            print("Input Limite Temps Actif")
                            self.input_limite_temps_active = True
                    
                    elif self.bouton_charger.collidepoint(event.pos) and not self.jeu_commence and not self.options: # Si le joueur clique sur "Charger"
                        if os.path.exists("save.txt"):
                            with open("save.txt", "r") as f:
                                data_grille = json.load(f)
                            self.grille = Grille(24,16,16,60)
                            self.grille.cases = data_grille["grille_cases"]
                            self.grille.cases_clic = data_grille["grille_cases_clic"]
                            self.grille.cases_drapeau = data_grille["grille_cases_drapeau"]
                            self.grille.adjacentes_decouvertes = data_grille["grille_adjacentes_decouvertes"]
                            self.nbr_drapeaux = data_grille["fenetre_nbr_drapeaux"]
                            self.nbr_cases_clic = data_grille["fenetre_nbr_cases_clic"]
                            self.delai_timer = data_grille["fenetre_duree_jeu"]
                            self.grille.est_prete = True
                            self.jeu_commence = True
                            self.debut_timer = pygame.time.get_ticks()
                            print("Partie Chargée")
                            print(self.grille.adjacentes_decouvertes)
    
                    elif self.bouton_sauver.collidepoint(event.pos) and self.jeu_commence and self.grille.est_prete and self.gagne == False and self.perdu == False: # Si le joueur clique sur "Sauver"
                        data = {
                            "grille_cases": self.grille.cases,
                            "grille_cases_clic": self.grille.cases_clic,
                            "grille_cases_drapeau": self.grille.cases_drapeau,
                            "grille_adjacentes_decouvertes": self.grille.adjacentes_decouvertes,
                            "fenetre_nbr_drapeaux": self.nbr_drapeaux,
                            "fenetre_nbr_cases_clic": self.nbr_cases_clic,
                            "fenetre_duree_jeu": self.ingame_timer
                        }
                        with open("save.txt", "w") as f:
                            json.dump(data, f)
                        print("Partie Sauvegardée")
                        
                    self.bouton_jouer_held = False
                    self.bouton_charger_held = False
                    self.bouton_sauver_held = False
                    self.bouton_rejouer_held = False
                    self.bouton_options_held = False
                    self.bouton_valider_held = False
                    self.bouton_quitter_held = False
                    
                elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1: # Si le joueur fait un clic gauche (enfoncé)
                    
                    if self.input_nbr_mines_active:
                        if self.input_nbr_mines == "" or self.input_nbr_mines == 0:
                            self.input_nbr_mines = 1
                        elif self.input_nbr_mines >= self.grille.cases_long * self.grille.cases_haut:
                            self.input_nbr_mines = self.grille.cases_long * self.grille.cases_haut - 9
                        self.grille.nbr_mines = self.input_nbr_mines
                        self.nbr_drapeaux = self.grille.nbr_mines
                        print("Input Nombre Mines Inactif")
                        self.input_nbr_mines_active = False
                    
                    if self.input_limite_temps_active:
                        if self.input_limite_temps == "" or self.input_limite_temps == 0:
                            self.input_limite_temps = 1
                        elif self.input_limite_temps >= 999:
                            self.input_limite_temps = 999
                        self.limite_temps = self.input_limite_temps
                        print("Input Limite Temps Inactif")
                        self.input_limite_temps_active = False
                    
                    if self.bouton_jouer.collidepoint(event.pos) and not self.jeu_commence and not self.options:
                        self.bouton_jouer_held = True
                    
                    elif self.bouton_charger.collidepoint(event.pos) and not self.jeu_commence and not self.options:
                        self.bouton_charger_held = True
                        
                    elif self.bouton_options.collidepoint(event.pos) and not self.jeu_commence and not self.options:
                        self.bouton_options_held = True
                        
                    elif self.bouton_valider.collidepoint(event.pos) and not self.jeu_commence and self.options:
                        self.bouton_valider_held = True
                        
                    elif self.bouton_sauver.collidepoint(event.pos) and self.jeu_commence:
                        self.bouton_sauver_held = True
                        
                    else:
                        for ligne in self.cases.keys():
                            for colonne,val in self.cases[ligne].items():
                                if val.collidepoint(event.pos) and self.jeu_commence: # Si le joueur clique sur une case de la grille
                                    
                                    if not self.grille.est_prete:
                                        self.grille.placer_mines(colonne,ligne,self.sur_autour)
                                        self.grille.calibrage()
                                        self.grille.est_prete = True
                                        self.debut_timer = pygame.time.get_ticks()
                                    
                                    if self.grille.cases[ligne][colonne] in [0,1,2,3,4,5,6,7,8] and not self.grille.cases_drapeau[ligne][colonne]:
                                        if not self.grille.cases_clic[ligne][colonne]:
                                            self.nbr_cases_clic += 1
                                            self.grille.cases_clic[ligne][colonne] = True
                                        if self.grille.cases[ligne][colonne] == 0:
                                            self.cases_adjacentes(self.grille,ligne,colonne)
                                        if self.nbr_cases_clic == self.grille.cases_long * self.grille.cases_haut - self.grille.nbr_mines and self.nbr_drapeaux == 0:
                                            self.gagne = True
                                            print("Vous Avez Gagné")
                                            
                                    elif self.grille.cases[ligne][colonne] == "M" and not self.grille.cases_drapeau[ligne][colonne]:
                                        self.grille.cases_clic[ligne][colonne] = True
                                        for ligne2 in range(len(self.grille.cases)):
                                            for colonne2 in range(len(self.grille.cases[ligne])):
                                                if self.grille.cases[ligne2][colonne2] == 'M':
                                                    self.grille.cases_clic[ligne2][colonne2] = True
                                        self.perdu = True
                                        print("Vous Avez Perdu")
                    
                elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 3: # Si le joueur fait un clic droit
                    
                    for ligne in self.cases.keys():
                        for colonne,val in self.cases[ligne].items():
                            if val.collidepoint(event.pos) and self.jeu_commence: # Si le joueur clique sur une case de la grille

                                if not self.grille.cases_clic[ligne][colonne]:
                                    if self.nbr_drapeaux > 0:
                                        if not self.grille.cases_drapeau[ligne][colonne]:
                                            self.grille.cases_drapeau[ligne][colonne] = True
                                            self.nbr_drapeaux -= 1
                                            if self.nbr_cases_clic == self.grille.cases_long * self.grille.cases_haut - self.grille.nbr_mines and self.nbr_drapeaux == 0:
                                                self.gagne = True
                                                print("Vous Avez Gagné")
                                        else:
                                            self.grille.cases_drapeau[ligne][colonne] = False
                                            self.nbr_drapeaux += 1
                                            
        if self.fin_jeu:
            
            for event in pygame.event.get(): # Attente des évènements
            
                if event.type == pygame.QUIT: # Si le jeu est quitté
                    self.en_cours = False
                    
                elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1: # Si le joueur fait un clic gauche (enfoncé)
                    
                    if self.bouton_rejouer.collidepoint(event.pos):
                        self.bouton_rejouer_held = True
                        
                    elif self.bouton_quitter.collidepoint(event.pos):
                        self.bouton_quitter_held = True
                        print("Fin Du Jeu")
                        self.rejouer = 2
                
                elif event.type == pygame.MOUSEBUTTONUP and event.button == 1: # Si le joueur fait un clic gauche (levé, pour éviter les bugs)
                        
                    if self.bouton_rejouer.collidepoint(event.pos): # Si le joueur clique sur "Rejouer"
                        print("Jeu Recommencé")
                        self.rejouer = 1
                        # Réinitialisation des attributs de FenetreJeu
                        self.reinitialiser_jeu()
                    
                    self.bouton_jouer_held = False
                    self.bouton_charger_held = False
                    self.bouton_sauver_held = False
                    self.bouton_rejouer_held = False
                    self.bouton_options_held = False
                    self.bouton_valider_held = False
                    self.bouton_quitter_held = False
                                
    def reinitialiser_jeu(self):
        """
        Réinitialise les attributs du jeu pour une nouvelle partie.
        """
        self.grille.reinitialiser()
        self.grille.est_prete = False
        self.cases = {}  # Redéfinir le dictionnaire des cases
        self.jeu_commence = False
        self.ingame_timer = 0
        self.delai_timer = 0
        self.grille.nbr_mines = data_options["nbr_mines"]
        self.mode_chrono = data_options["mode_chrono"]
        self.sur_autour = data_options["sur_autour"]
        self.limite_temps = data_options["limite_temps"]
        self.nbr_drapeaux = self.grille.nbr_mines
        self.nbr_cases_clic = 0
        self.fin_jeu = False
        self.last_frame = False
        self.perdu = False
        self.gagne = False
        self.rejouer = 0
        
    def dessiner(self):
        """
        Dessine le contenu du jeu à l'écran.
        """
        
        # Chargement des images du jeu
        for i in range(self.grille.cases_haut):
            self.cases[i] = {}
            for j in range(self.grille.cases_long):
                self.cases[i][j] = pygame.Rect(self.largeur // 2 - 0.5 * (self.grille.cases_long * self.grille.taille_case + self.grille.cases_long * 2) + j*(self.grille.taille_case + 2) + 10, 75 + (self.hauteur - 75) // 2 - 0.5 * (self.grille.cases_haut * self.grille.taille_case + self.grille.cases_haut * 2) + i*(self.grille.taille_case + 2) + 10, self.grille.taille_case, self.grille.taille_case)
        
        image_fond = pygame.image.load('images/fond.jpg').convert_alpha()
        image_fond= pygame.transform.scale(image_fond,(self.largeur,self.hauteur))
        image_case = pygame.image.load('images/case.png').convert_alpha()
        image_case_clic = pygame.image.load('images/case_clic.png').convert_alpha()
        image_bombe = pygame.image.load('images/bombe.png').convert_alpha()
        image_drapeau = pygame.image.load('images/drapeau.png').convert_alpha()
        image_timer = pygame.image.load('images/timer.png').convert_alpha()
        image_bouton_jouer = pygame.image.load('images/bouton_jouer.png').convert_alpha()
        image_bouton_jouer_held = pygame.image.load('images/bouton_jouer_held.png').convert_alpha()
        image_bouton_charger = pygame.image.load('images/bouton_charger.png').convert_alpha()
        image_bouton_charger_held = pygame.image.load('images/bouton_charger_held.png').convert_alpha()
        image_bouton_rejouer = pygame.image.load('images/bouton_rejouer.png').convert_alpha()
        image_bouton_rejouer_held = pygame.image.load('images/bouton_rejouer_held.png').convert_alpha()
        image_bouton_quitter = pygame.image.load('images/bouton_quitter.png').convert_alpha()
        image_bouton_quitter_held = pygame.image.load('images/bouton_quitter_held.png').convert_alpha()
        image_bouton_options = pygame.image.load('images/bouton_options.png').convert_alpha()
        image_bouton_options_held = pygame.image.load('images/bouton_options_held.png').convert_alpha()
        image_bouton_valider = pygame.image.load('images/bouton_valider.png').convert_alpha()
        image_bouton_valider_held = pygame.image.load('images/bouton_valider_held.png').convert_alpha()
        image_slider_on = pygame.image.load('images/slider_on.png').convert_alpha()
        image_slider_off = pygame.image.load('images/slider_off.png').convert_alpha()
        image_bouton_sauver = pygame.image.load('images/bouton_sauver.png').convert_alpha()
        image_bouton_sauver_held = pygame.image.load('images/bouton_sauver_held.png').convert_alpha()
        image_titre_jeu = pygame.image.load('images/titre_jeu.png').convert_alpha()
        image_titre_jeu = pygame.transform.scale(image_titre_jeu,(500,76))
                
        # Chargement des polices et d'images supplémentaires
        pol1 = pygame.font.SysFont('Bahnschrift',30,italic=True,bold=True)
        pol2 = pygame.font.SysFont('Bahnschrift',65,italic=True,bold=True)
        pol3 = pygame.font.SysFont('Bahnschrift', int(self.grille.taille_case * 0.6), italic=True, bold=True)
        pol4 = pygame.font.SysFont('Bahnschrift',45,italic=True,bold=True)
        
        if not self.jeu_commence: # Menu d'ouverture
            
            if not self.options:
                self.fenetre.blit(image_fond,(0,0)) # Fond d'écran
                self.fenetre.blit(image_titre_jeu,(100,self.hauteur // 5))
                if not self.bouton_jouer_held:
                    self.fenetre.blit(image_bouton_jouer,self.bouton_jouer)
                else:
                    self.fenetre.blit(image_bouton_jouer_held,self.bouton_jouer)
                if not self.bouton_charger_held:
                    self.fenetre.blit(image_bouton_charger,self.bouton_charger)
                else:
                    self.fenetre.blit(image_bouton_charger_held,self.bouton_charger)
                police2 = pygame.font.SysFont('Bahnschrift', 30)
                txt_nom = police2.render("© Renzistupid 2025", True, (255, 255, 255))
                self.fenetre.blit(txt_nom, (0.6*self.largeur, self.hauteur - 35))
                if not self.bouton_options_held:
                    self.fenetre.blit(image_bouton_options,self.bouton_options)
                else:
                    self.fenetre.blit(image_bouton_options_held,self.bouton_options)
            else:
                self.fenetre.blit(image_fond,(0,0)) # Fond d'écran
                self.fenetre.blit(image_titre_jeu,(100,self.hauteur // 5))
                police2 = pygame.font.SysFont('Bahnschrift', 30)
                police3 = pygame.font.SysFont('Bahnschrift', 24, italic=True, bold=True)
                txt_nom = police2.render("© Renzistupid 2025", True, (255, 255, 255))
                self.fenetre.blit(txt_nom, (0.6*self.largeur, self.hauteur - 35))
                if not self.bouton_valider_held:
                    self.fenetre.blit(image_bouton_valider,self.bouton_valider)
                else:
                    self.fenetre.blit(image_bouton_valider_held,self.bouton_valider)
                if self.sur_autour :
                    self.fenetre.blit(image_slider_on,self.bouton_diff)
                else :
                    self.fenetre.blit(image_slider_off,self.bouton_diff)
                if self.mode_chrono :
                    self.fenetre.blit(image_slider_on,self.bouton_mode_chrono)
                else :
                    self.fenetre.blit(image_slider_off,self.bouton_mode_chrono)
                pygame.draw.rect(self.fenetre, (255, 255, 255), self.box_input_limite_temps)
                pygame.draw.rect(self.fenetre, (0,0,0), (self.box_input_limite_temps.x + 0.05 * self.box_input_limite_temps.width, self.box_input_limite_temps.y + 0.1 * self.box_input_limite_temps.height, 0.9 * self.box_input_limite_temps.width, 0.8 * self.box_input_limite_temps.height))
                pygame.draw.rect(self.fenetre, (255, 255, 255), self.box_input_nbr_mines)
                pygame.draw.rect(self.fenetre, (0,0,0), (self.box_input_nbr_mines.x + 0.05 * self.box_input_nbr_mines.width, self.box_input_nbr_mines.y + 0.1 * self.box_input_nbr_mines.height, 0.9 * self.box_input_nbr_mines.width, 0.8 * self.box_input_nbr_mines.height))
                txt_input_nbr_mines = pol1.render(str(self.input_nbr_mines), True, (255,255,255))
                txt_input_limite_temps = pol1.render(str(self.input_limite_temps), True, (255,255,255))
                self.fenetre.blit(txt_input_limite_temps, (self.box_input_limite_temps.x + 0.05 * self.box_input_limite_temps.width, self.box_input_limite_temps.y + 0.1 * self.box_input_limite_temps.height, 0.9 * self.box_input_limite_temps.width, 0.8 * self.box_input_limite_temps.height))
                self.fenetre.blit(txt_input_nbr_mines, (self.box_input_nbr_mines.x + 0.05 * self.box_input_nbr_mines.width, self.box_input_nbr_mines.y + 0.1 * self.box_input_nbr_mines.height, 0.9 * self.box_input_nbr_mines.width, 0.8 * self.box_input_nbr_mines.height))
                txt_nbr_mines = police3.render("Nombre de mines :", True, (255,255,255))
                self.fenetre.blit(txt_nbr_mines, (self.largeur // 5, self.hauteur * 0.4 + 3 * (self.bouton_hauteur * 0.7 + 20) + 5))
                txt_limite_temps = police3.render("Limite de temps :", True, (255,255,255))
                self.fenetre.blit(txt_limite_temps, (self.largeur // 5, self.hauteur * 0.4 + 2 * (self.bouton_hauteur * 0.7 + 20) + 5))
                txt_diff = police3.render("Mode facile :", True, (255, 255, 255))
                self.fenetre.blit(txt_diff, (self.largeur // 5, self.hauteur * 0.4 + 8))
                txt_mode_chrono = police3.render("Mode contre-la-montre :", True, (255, 255, 255))
                self.fenetre.blit(txt_mode_chrono, (self.largeur // 5, self.hauteur * 0.4 + self.bouton_hauteur * 0.7 + 25))
                
            
        elif self.jeu_commence and not self.fin_jeu: # Pendant la partie
            
            self.fenetre.blit(image_fond,(0,0))  # Fond d'écran
            pygame.draw.rect(self.fenetre, (255,255,255), (self.largeur // 2 - 0.5 * (self.grille.cases_long * self.grille.taille_case + self.grille.cases_long * 2), 75 + (self.hauteur - 75) // 2 - 0.5 * (self.grille.cases_haut * self.grille.taille_case + self.grille.cases_haut * 2), self.grille.cases_long*self.grille.taille_case + self.grille.cases_long*2 + 18, self.grille.cases_haut*self.grille.taille_case + self.grille.cases_haut*2 + 18))
            pygame.draw.rect(self.fenetre, self.couleur_fond, (5 + self.largeur // 2 - 0.5 * (self.grille.cases_long * self.grille.taille_case + self.grille.cases_long * 2), 80 + (self.hauteur - 75) // 2 - 0.5 * (self.grille.cases_haut * self.grille.taille_case + self.grille.cases_haut * 2), self.grille.cases_long*self.grille.taille_case + self.grille.cases_long*2 + 8, self.grille.cases_haut*self.grille.taille_case + self.grille.cases_haut*2 + 8))
            for ligne in self.cases.keys() :
                for colonne in self.cases[ligne].keys():
                    self.fenetre.blit(image_case, self.cases[ligne][colonne])
                    if self.grille.cases_clic[ligne][colonne]:
                        self.fenetre.blit(image_case_clic, self.cases[ligne][colonne])
                        if self.grille.cases[ligne][colonne] == 'M':
                            self.fenetre.blit(image_bombe, self.cases[ligne][colonne])
                        else :
                            num = pol3.render(str(self.grille.cases[ligne][colonne]), True, (0,0,0))
                            self.fenetre.blit(num, (self.cases[ligne][colonne]))
                    if self.grille.cases_drapeau[ligne][colonne]:
                        self.fenetre.blit(image_drapeau, self.cases[ligne][colonne])
            pygame.draw.rect(self.fenetre, (255, 255, 255), (230, 15, 250, 60))
            pygame.draw.rect(self.fenetre, (0,0,0), (235, 20, 240, 50))
            pygame.draw.rect(self.fenetre, (255, 255, 255), (350, 15, 5, 60))
            txt_drapeau = pol4.render(str(self.nbr_drapeaux), True, (255,255,255))
            self.fenetre.blit(txt_drapeau,(240,25))
            if not self.bouton_sauver_held:
                self.fenetre.blit(image_bouton_sauver,self.bouton_sauver)
            else:
                self.fenetre.blit(image_bouton_sauver_held,self.bouton_sauver)
            image_drapeau = pygame.transform.scale(image_drapeau,(40,40))
            self.fenetre.blit(image_drapeau,(310,25))
            txt_timer = pol4.render(str(self.ingame_timer), True, (255,255,255))
            self.fenetre.blit(txt_timer,(355,25))
            image_timer = pygame.transform.scale(image_timer,(40,40))
            self.fenetre.blit(image_timer,(430,25))
            
            if self.perdu or self.gagne :
                self.fin_jeu = True

        elif self.fin_jeu: # Ecran de victoire/défaite
            
            if not self.last_frame:
                pygame.time.wait(1400)
                self.last_frame = True
            self.fenetre.blit(image_fond,(0,0))  # Fond d'écran
            
            if self.perdu :
                pygame.draw.rect(self.fenetre, self.couleur_fond, (170, 90, 365, 150))
                txt_perdu1 = pol2.render("Dommage !", True, (255, 255, 255))
                txt_perdu2 = pol1.render("Vous avez perdu !", True, (255, 255, 255))
                self.fenetre.blit(txt_perdu1, (180, 100))
                self.fenetre.blit(txt_perdu2, (225, 190))
                if self.bouton_rejouer_held:
                    self.fenetre.blit(image_bouton_rejouer_held,self.bouton_rejouer)
                else:
                    self.fenetre.blit(image_bouton_rejouer,self.bouton_rejouer)
                self.fenetre.blit(image_bouton_quitter,self.bouton_quitter)
            
            else :
                pygame.draw.rect(self.fenetre, self.couleur_fond, (170, 90, 345, 150))
                txt_gagne1 = pol2.render("Bien joué !", True, (255, 255, 255))
                txt_gagne2 = pol1.render("Vous avez gagné !", True, (255, 255, 255))
                self.fenetre.blit(txt_gagne1, (189, 100))
                self.fenetre.blit(txt_gagne2, (225, 190))
                if self.bouton_rejouer_held:
                    self.fenetre.blit(image_bouton_rejouer_held,self.bouton_rejouer)
                else:
                    self.fenetre.blit(image_bouton_rejouer,self.bouton_rejouer)
                if self.bouton_quitter_held:
                    self.fenetre.blit(image_bouton_quitter_held,self.bouton_quitter)
                else:
                    self.fenetre.blit(image_bouton_quitter,self.bouton_quitter)
                
            if self.rejouer == 2:
                pygame.display.flip()
                self.en_cours = False
            
# Main
grille_debut = Grille(24,16,16,options_nbr_mines)
grille_debut.creation()

jeu = FenetreJeu(700, 600, "Démineur", grille_debut)
jeu.lancer_jeu()
